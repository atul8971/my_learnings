import boto3

# Initialize the EMR client
emr_client = boto3.client('emr', region_name='ap-south-1')

# Create the cluster
response =emr_client.run_job_flow(
    Name="My cluster",
    LogUri="s3://aws-logs-816069129520-ap-south-1/elasticmapreduce",
    ReleaseLabel="emr-7.4.0",
    ServiceRole="arn:aws:iam::816069129520:role/emr-role",
    AutoTerminationPolicy={
        'IdleTimeout': 3600  # Terminate after 1 hour of idle time
    },
    ScaleDownBehavior="TERMINATE_AT_TASK_COMPLETION",
    Applications=[
        {'Name': 'Hadoop'},
        {'Name': 'Hive'},
        {'Name': 'JupyterEnterpriseGateway'},
        {'Name': 'Spark'}
    ],
    Configurations=[
        {
            'Classification': 'hive-site',
            'Properties': {
                'hive.metastore.client.factory.class': 'com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory'
            }
        },
        {
            'Classification': 'spark-hive-site',
            'Properties': {
                'hive.metastore.client.factory.class': 'com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory'
            }
        }
    ],
    Instances={
        'InstanceGroups': [
            {
                'InstanceCount': 1,
                'InstanceRole': 'MASTER',  # Specify the role of this instance group
                'Name': 'Primary',
                'InstanceType': 'm5.xlarge',
                'EbsConfiguration': {
                    'EbsBlockDeviceConfigs': [
                        {
                            'VolumeSpecification': {
                                'VolumeType': 'gp2',
                                'SizeInGB': 32
                            },
                            'VolumesPerInstance': 2
                        }
                    ]
                }
            }
        ],
        'Ec2KeyName': 'atul-aws-key',
        'EmrManagedMasterSecurityGroup': 'sg-0b2bcef5ee2dc8414',
        'EmrManagedSlaveSecurityGroup': 'sg-0c0f673dbfcd72cba',
        'Ec2SubnetId': 'subnet-04b70fbf3ac9cf368'  # Correct parameter
    },
    Steps=[
        {
            'Name': 'read_json_pyspark_2',
            'ActionOnFailure': 'CONTINUE',
            'HadoopJarStep': {
                'Jar': 'command-runner.jar',
                'Args': [
                    'spark-submit',
                    '--deploy-mode', 'cluster',
                    '--py-files', 's3://atul.data/spark_app_code.zip',
                    's3://atul.data/app.py'
                ]
            }
        }
    ],
    JobFlowRole="emr-role-for-ec2"
)

# Print the response
print("Cluster created with ID:", response['JobFlowId'])
