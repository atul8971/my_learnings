import boto3

def upload_to_s3(bucket,key,body):
    s3_client=boto3.client('s3')
    upload_res=s3_client.put_object(Bucket=bucket, Key=key, Body=body)
    print(f"upload_res:{upload_res}")
