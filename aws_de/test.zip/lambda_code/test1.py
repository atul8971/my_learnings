import requests
def download_file(file_url):
    res=requests.get(f'https://data.gharchive.org/{file_url}')
    return res.status_code,res.content