import json
from test1 import download_file
import os
from upload_code import upload_to_s3
def sade(event, context):
    status_code,body = download_file(file_url=os.getenv('file_url'))
    upload_to_s3(bucket=os.getenv('bucket'),key=os.getenv('file_url'),body=body)
    return {
        'statusCode': status_code,
        'body': json.dumps(f'downloaded to s3 {os.getenv("file_url")}')
    }